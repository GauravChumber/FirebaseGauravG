package com.example.firebasegauravg

data class Person(var name: String ="", var role: String ="", var photo: String ="", var age: Int? = null){

}

